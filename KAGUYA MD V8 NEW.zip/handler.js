/**

* Kaguya Multi Device — WhatsApp & Tele Bot
* 
* Library      : whiskeysockets baileys
* Type         : Plugins | ESM Modules
* Creator      : YannRzy Tech
* Recode       : (Your Name)
* 
* Developer Channels:
* • https://whatsapp.com/channel/0029VaoMGuLA89MbfGh62V16
*
* Info Update Kaguya Channels:
* • https://whatsapp.com/channel/0029VabymHd4CrfnqPLPzk3n
* 
* Copyright © YannRzy Tech 2026
* All Rights Reserved.
  */


import chalk from 'chalk'
import { cekLimit, rpgStore, toPN, initPlugins, matchPlugin, matchSub, routeSub, sendExample, parseCommand, primaryPrefix, runPassivePlugins, afkCheck, telegramHidden, isTelegramHidden, wajibDaftarOn, isRegisterFree, isRegisteredUser, promptRegister, botModeOn, isBotModeAllowed } from './lib/engine/plugins.js'
import { fiturWatch, fiturLog, fiturBlacklisted } from './lib/engine/features.js'
import { runDevtools, saveDB } from './lib/core/system.js'
import path from 'path'
import fs from 'fs'
import { AsyncLocalStorage } from 'async_hooks'
import { fileURLToPath } from 'url'

import { trackMisi } from './lib/engine/features.js'
import { trackBadge } from './lib/rpg/extra.js'
import { isOwnerNumber } from './lib/core/system.js'
import { credCtx } from './lib/core/usercreds.js'
import { groupGuard, getMeta, isAdminJid, captureViewOnce } from './lib/platform/wa.js'
import { runCustom as runGroupCustom } from './lib/group/sosial.js'
import { isPremiumUser, isChatBanned, isUserBanned, recordCommand, isGroupRented, isGroupbotOn, isGroupAllowed, autoBlockPM } from './lib/core/data.js'

const PLUGINS_DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'plugins')

// Limit hanya terpakai kalau fitur BENAR-BENAR dipakai.
//
//   .pin              -> cuma menampilkan cara pakai  => limit TIDAK berkurang
//   .pin kaguya       -> fitur jalan                  => limit berkurang
//   .daily            -> fitur tanpa input, jalan     => limit berkurang (normal)
//
// Cara kerja: kalau command dikirim TANPA input (tanpa teks, tanpa reply, tanpa media,
// tanpa tag), pemotongan limit oleh plugin tetap berjalan seperti biasa, tapi notif
// "limit terpakai" ditahan dulu. Setelah plugin selesai:
//   - plugin cuma menampilkan cara pakai  -> limit dikembalikan, notif dibuang
//   - plugin menjalankan fitur            -> notif dikirim seperti biasa
// "Cara pakai" dikenali dari isi pesan yang dikirim plugin (Contoh / Usage / cara pakai /
// baris "<command> <argumen> → ..." dst) dan dari kode plugin (cek input kosong).
// Berlaku untuk SEMUA plugin yang memotong limit (handler biasa, adapt rpg, rpgPlugin).
const tapStore = new AsyncLocalStorage()

const MEDIA = new Set([
    'imageMessage', 'videoMessage', 'audioMessage', 'stickerMessage', 'documentMessage',
    'documentWithCaptionMessage', 'ptvMessage', 'viewOnceMessage', 'viewOnceMessageV2'
])

/** Apakah pesan membawa input (teks setelah command, reply, media, atau tag)? */
function hasInput(m, ctx) {
    if (String(ctx?.text ?? '').trim()) return true
    if (m?.quoted) return true
    if (Array.isArray(m?.mentionedJid) && m.mentionedJid.length) return true
    if (MEDIA.has(m?.mtype)) return true
    return false
}

// ───────── membaca pesan keluar ─────────
function textOf(content) {
    if (!content || typeof content !== 'object') return ''
    return String(
        content.text ?? content.caption ?? content.conversation ??
        content.extendedTextMessage?.text ?? content.image?.caption ?? content.video?.caption ?? ''
    )
}

// teks dari pesan proto (reply card dikirim lewat relayMessage: teks ada di dalam extendedTextMessage dst)
function deepText(msg, depth = 0) {
    if (!msg || typeof msg !== 'object' || depth > 6) return ''
    for (const k of ['text', 'caption', 'conversation']) {
        if (typeof msg[k] === 'string' && msg[k].trim()) return msg[k]
    }
    for (const k of Object.keys(msg)) {
        if (k === 'contextInfo' || k === 'jpegThumbnail') continue
        const t = deepText(msg[k], depth + 1)
        if (t) return t
    }
    return ''
}

function observe(content) {
    const st = tapStore.getStore()
    if (!st) return
    st.sent++
    if (st.usage) return
    const t = textOf(content) || deepText(content)
    if (t && isUsageText(t, st.command)) st.usage = true
}

/** Pasang pengintai di sock.sendMessage dan sock.relayMessage (sekali saja per sock). */
function installTap(sock) {
    if (!sock || sock.__limitTap) return
    sock.__limitTap = true
    if (typeof sock.sendMessage === 'function') {
        const send = sock.sendMessage.bind(sock)
        sock.sendMessage = (jid, content, ...rest) => { observe(content); return send(jid, content, ...rest) }
    }
    if (typeof sock.relayMessage === 'function') {
        const relay = sock.relayMessage.bind(sock)
        sock.relayMessage = (jid, message, ...rest) => { observe(message); return relay(jid, message, ...rest) }
    }
}

const esc = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

const KEYWORD = /\b(contoh|example|usage|cara\s+(?:pakai|penggunaan|menggunakan)|penggunaan|format\s*:|masukkan|masukan)\b/i
const NEED = /\b(reply|balas|kirim|tag|sertakan|ketik|isi)\b[^\n]{0,40}\b(gambar|foto|video|audio|link|url|teks|text|pesan|pertanyaan|nama|username|id|kata|kunci|nomor|stiker|sticker|media)\b/i

/** Teks ini kelihatan seperti petunjuk cara pakai command? */
function isUsageText(text, command) {
    const t = String(text || '')
    if (!t.trim()) return false
    if (KEYWORD.test(t)) return true
    if (NEED.test(t)) return true
    const cmd = String(command || '').trim()
    if (cmd) {
        // baris yang diawali command lalu contoh argumen:  ".pin <kata>"  /  "pin kaguya → cari 5 gambar"
        const line = new RegExp(
            `(?:^|\\n)[\\s>•\\-*_\`▪▫◦]*[./!#]?${esc(cmd)}[ \\t]+(?:<|\\[|@|https?:|[^\\n]*(?:→|->|=>|\\|))`, 'i')
        if (line.test(t)) return true
    }
    return false
}

// ───────── cek kode plugin: ada penjaga "input kosong"? ─────────
const ACT = '(?:return|throw|await\\s+(?:m\\.)?reply|(?:m\\.|conn\\.|sock\\.)?reply|sock\\.sendMessage|example)'
const NM = '(?:text|input|query|q|teks|url|link|prompt|pesan|kata|keyword|name|nama|code|kode|username|lang|jumlah|amount|args\\[0\\]|args\\[1\\]|args\\.length|ctx\\.text|who|target|user|id|number|nomor|mime|quoted|msg)'
const GUARDS = [
    new RegExp(`if\\s*\\(\\s*!\\s*\\(?\\s*(?:m\\.)?${NM}\\b[^\\n]*?\\)\\s*\\{?\\s*(?:\\n\\s*)?${ACT}`),
    new RegExp(`if\\s*\\(\\s*(?:args\\.length|text\\.length|input\\.length)\\s*(?:<|===?|==)\\s*[01]\\b[^\\n]*?\\)\\s*\\{?\\s*(?:\\n\\s*)?${ACT}`),
    new RegExp(`if\\s*\\(\\s*!\\s*(?:\\/[^/]+\\/\\.test|(?:mime|mimetype)\\.(?:includes|startsWith))[^\\n]*?\\)\\s*\\{?\\s*(?:\\n\\s*)?${ACT}`),
    /\bexample\(/,
    /ctx\.example/
]
const sourceHasEmptyGuard = (src) => GUARDS.some(r => r.test(src))

const guardCache = new WeakMap() // plugin (fungsi) -> boolean; plugin di-reload = objek baru = dicek ulang

function pluginHasEmptyGuard(plugin, pluginsDir) {
    if (!plugin || (typeof plugin !== 'function' && typeof plugin !== 'object')) return false
    if (guardCache.has(plugin)) return guardCache.get(plugin)
    let result = false
    try {
        const key = Object.keys(global.plugins || {}).find(k => global.plugins[k] === plugin)
        if (key && pluginsDir) {
            const file = path.join(pluginsDir, key.replace(/^\/+/, ''))
            if (fs.existsSync(file)) result = sourceHasEmptyGuard(fs.readFileSync(file, 'utf8'))
        }
    } catch { }
    guardCache.set(plugin, result)
    return result
}

/**
 * Mulai mode "tanpa input". Panggil sebelum plugin jalan, lalu:
 *   await run(() => plugin(m, ctx))   -> jalankan plugin di dalam pengintai
 *   await gate.finish()               -> plugin selesai normal (kembalikan limit / kirim notif)
 *   gate.cancel()                     -> plugin error (tidak ada notif tersisa)
 *
 * deps: { sock, m, ctx, plugin, pluginsDir, getUser: async () => userRpg|null, save: () => void }
 */
async function beginBare({ sock, m, ctx, plugin, pluginsDir, getUser, save }) {
    installTap(sock)

    const userBefore = await getUser().catch(() => null)
    const before = userBefore && Number.isFinite(Number(userBefore.limit)) ? Number(userBefore.limit) : null

    const held = []                   // notif "limit terpakai" yang ditahan
    const originalReply = ctx.reply
    ctx.reply = function (text, ...rest) {
        if (typeof text === 'string' && /limit terpakai/i.test(text)) {
            held.push([text, rest])
            return Promise.resolve(null)
        }
        return originalReply.call(this, text, ...rest)
    }

    const state = { usage: false, sent: 0, command: ctx.command }
    let done = false
    const restore = () => { if (!done) { done = true; ctx.reply = originalReply } }

    return {
        run: (fn) => tapStore.run(state, fn),
        async finish() {
            restore()
            const usage = state.usage || pluginHasEmptyGuard(plugin, pluginsDir)
            if (usage) {
                // cuma cara pakai: kembalikan limit, buang notif
                const u = await getUser().catch(() => null)
                if (u) {
                    const base = before ?? 20
                    if (Number(u.limit) < base) { u.limit = base; try { save() } catch { } }
                }
                return false
            }
            // fitur benar-benar jalan: kirim notif yang tadi ditahan
            for (const [text, rest] of held) await originalReply.call(ctx, text, ...rest).catch(() => null)
            return true
        },
        cancel() { restore() }
    }
}

// command yang tetap boleh dipakai di grup yang belum menyewa
const SEWA_FREE = new Set(['sewa'])

// Mode self / public dipisah per platform:
//   WhatsApp -> global.public           Telegram -> global.publicTelegram
// (kalau publicTelegram belum diisi, Telegram mengikuti global.public)
global.isPublic = (platform) => platform === 'telegram'
    ? (global.publicTelegram === undefined ? global.public === true : global.publicTelegram === true)
    : global.public === true

const green = (t) => chalk.greenBright(t)
const blue = (t) => chalk.cyanBright(t)

await initPlugins()

// cetak log command masuk ke terminal (lengkap + banner ASCII + teks RGB)
// Banner & efek RGB diambil dari index.js (global.randomAscii / global.rainbowText).
// Matikan banner ASCII: global.logAscii = false di config.js
async function logMessage(isCmd, d) {
    const {
        sock, m, pushName, number, chatType, jid, prefix, command, text, mtype, body,
        isOwner, isTelegram, isGroup
    } = d

    const now = new Date()
    const time = now.toLocaleTimeString('id-ID')
    const date = now.toLocaleDateString('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' })

    // nama grup + jumlah member (dari cache metadata, gagal = dilewati)
    let groupName = ''
    let members = 0
    if (isGroup && !isTelegram) {
        try {
            const meta = await getMeta(sock, jid)
            groupName = meta?.subject || ''
            members = meta?.participants?.length || 0
        } catch {}
    }

    const access = isOwner ? 'Owner' : 'User'
    const platform = isTelegram ? 'Telegram' : 'WhatsApp'
    const mode = global.isPublic(isTelegram ? 'telegram' : 'whatsapp') ? 'Public' : 'Self'

    const rows = [
        `┌─ [ ${isCmd ? 'COMMAND' : 'MESSAGE'} DETECTED ] ───`,
        `│ Bot      : ${global.namebot || 'Bot'} (${mode})`,
        `│ Platform : ${platform}`,
        `│ Tanggal  : ${date}`,
        `│ Waktu    : ${time}`,
        `│ User     : ${pushName || 'No Name'} (@${number})`,
        `│ Akses    : ${access}${m?.fromMe ? ' (akun bot)' : ''}`,
        `│ Room     : ${chatType} (${jid})`
    ]
    if (groupName) rows.push(`│ Grup     : ${groupName}${members ? ` (${members} member)` : ''}`)
    rows.push('┠─ [ DATA ] ───')

    if (isCmd) {
        rows.push(`│ Cmd      : ${prefix}${command}`)
        rows.push(`│ Prefix   : ${prefix || '-'}`)
        rows.push(`│ Args     : ${text || '-'}`)
    } else {
        rows.push(`│ Text     : ${body}`)
    }
    rows.push(`│ Type     : ${mtype || m?.mtype || m?.type || '-'}`)
    rows.push(`│ Msg ID   : ${m?.id || m?.key?.id || '-'}`)
    rows.push(`│ Panjang  : ${String(body || '').length} karakter`)
    rows.push('└───────────────────────────')

    // banner ASCII acak dari index.js (yangBacaHomo)
    let ascii = ''
    if (global.logAscii !== false && typeof global.randomAscii === 'function') {
        ascii = String(global.randomAscii()).replace(/^\n+|\n+$/g, '')
    }

    const out = [ascii, ascii ? '' : null, rows.join('\n')].filter(v => v !== null).join('\n')

    // satu console.log supaya tidak terselip log lain
    if (typeof global.rainbowText === 'function') {
        console.log(global.rainbowText(out) + '\n')
    } else {
        console.log((isCmd ? green : blue)(out) + '\n')
    }
}

// ═══════════════ SELF / PUBLIC BOT ═══════════════
// global.public = false (default): bot hanya merespon akun sendiri (fromMe) dan nomor
//   di global.owners. Pesan dari orang lain diabaikan total.
// global.public = true: semua orang bisa memakai bot. Command khusus owner / premium /
//   admin tetap dikunci, dan eval (=>, >, $) tetap hanya untuk owner.
// Owner Telegram: hanya ID numerik di global.telegram.owners (username bisa berpindah tangan,
// dan nomor owner WhatsApp sengaja tidak dipakai supaya tidak bisa bentrok dengan ID Telegram).
function isTelegramOwner(number) {
    const ids = [].concat(global.telegram?.owners || []).map(v => String(v).replace(/\D/g, '')).filter(Boolean)
    return ids.includes(String(number).replace(/\D/g, ''))
}

// fungsi utama: dipanggil tiap ada pesan baru dari index.js / jadibot
export const handler = async (sock, m) => {
    if (!m.message) return
    // (isBaileys dihapus: bot lain berbasis Baileys ikut terdeteksi sebagai bot sendiri; pesan sendiri sudah ditangani m.fromMe + botSentIds)
    if (global.botSentIds?.has(m.id)) return // cegah bot membalas pesannya sendiri

    const jid = m.chat
    if (!jid || jid === 'status@broadcast' || m.isNewsletter) return

    // Satu pesan bisa diterima dua socket kalau nomor jadibot sama dengan akun yang sudah
    // jalan (mis. nomor bot utama). Tanpa ini command jalan 2x dan salah satunya error
    // ("Tidak ada sesi jadibot aktif" setelah stopjadibot berhasil, dst).
    global.handledMsgs = global.handledMsgs || new Set()
    const selfId = String(sock.user?.id || '').split('@')[0].split(':')[0]
    const dedupeKey = `${selfId}|${jid}|${m.id}`
    if (global.handledMsgs.has(dedupeKey)) return
    global.handledMsgs.add(dedupeKey)
    if (global.handledMsgs.size > 1000) global.handledMsgs.delete(global.handledMsgs.values().next().value)

    const isGroup = m.isGroup
    // sender = identitas (nomor, sudah di-convert dari LID oleh lib/core/lid.js); jid tetap dipakai untuk kirim pesan
    // sesi jadibot: pesan fromMe berarti pemilik nomor jadibot itu sendiri -> perlakukan sebagai user biasa
    const isJadi = sock.isJadiBot === true
    // fromMe yang punya hak istimewa (owner/admin/bebas daftar) HANYA di bot utama, tidak di sesi jadibot
    const selfPriv = !!m.fromMe && !isJadi
    // di chat pribadi, pesan fromMe tercatat ke lawan bicara; di jadibot identitas pengirim harus nomor jadibot-nya
    const sender = isGroup || (isJadi && m.fromMe) ? (m.sender || m.key.participant) : (m.chatPn || jid)
    const number = sender?.split('@')[0] || '-'

    // platform: 'telegram' kalau pesan datang dari adapter Telegram, selain itu WhatsApp
    const isTelegram = sock.platform === 'telegram'

    // owner = nomor di config.js / .addowner (atau akun bot utama). Pemilik nomor jadibot BUKAN owner,
    // kecuali nomornya didaftarkan owner lewat .addowner
    const isOwner = selfPriv || (isTelegram ? isTelegramOwner(number) : await isOwnerNumber(sock, number))

    // AUTO BLOCK PM (global.autoblockpm): non-owner yang chat pribadi ke bot langsung diblokir
    if (!isGroup && !isTelegram && await autoBlockPM(sock, m, { isOwner })) return

    // SEWA BOT: kalau global.sewamode aktif, grup yang belum menyewa (atau masa sewanya habis) tidak dilayani sama sekali,
    // termasuk penjaga grup. Hanya command sewa yang boleh. Owner selalu lolos.
    if (isGroup && !isTelegram && !isOwner && global.sewamode === true && !isGroupRented(jid)) {
        const early = parseCommand(m.body || '')
        if (!(early.isCmd && SEWA_FREE.has(early.command))) {
            if (early.isCmd) {
                const notices = (global.sewaNotice ||= new Map())
                if (Date.now() - (notices.get(jid) || 0) > 6 * 36e5) {
                    notices.set(jid, Date.now())
                    await m.reply('⛔ Grup ini belum menyewa bot atau masa sewanya sudah habis.\nKetik *' + (early.prefix || primaryPrefix() || '.') + 'sewa* untuk melihat paket dan cara sewa.').catch(() => null)
                }
            }
            return
        }
    }

    // antidelete / antiedit / anti sekali lihat GLOBAL (config.js -> global.fitur), grup & chat pribadi
    // media sekali lihat diunduh & disimpan SAAT MASUK (dipakai .rvo dan antiviewonce); harus sebelum fiturWatch supaya unduhannya dibagi
    if (!isTelegram) captureViewOnce(sock, m)
    if (!isTelegram) await fiturWatch(sock, m)

    // penjaga grup (antilink, antitoxic, antispam, antidelete, autoreply) jalan untuk semua pengirim
    // (khusus WhatsApp: bergantung pada event & metadata grup WhatsApp)
    if (isGroup && !isTelegram) await groupGuard(sock, m, { isOwner })

    // GRUPBOT (.grupbot on): bot hanya melayani grup yang ada di daftar. Grup di daftar dilayani untuk SEMUA member
    // walau bot mode self. Grup di luar daftar diabaikan (kecuali owner). Private chat tetap ikut mode self/public.
    const grupbotOn = isGroup && !isTelegram && isGroupbotOn()
    const grupListed = grupbotOn && isGroupAllowed(jid)
    if (grupbotOn && !grupListed && !isOwner) return

    // mode self: orang lain diabaikan total. mode public: semua boleh lanjut. (dicek per platform)
    if (!isOwner && !grupListed && !global.isPublic(isTelegram ? 'telegram' : 'whatsapp')) return

    // pconly / gconly: bot hanya melayani private chat atau grup. Owner tetap dilayani supaya bisa mematikannya.
    if (!isOwner && ((global.pconly === true && isGroup) || (global.gconly === true && !isGroup))) return

    // user yang di-ban (.ban): diabaikan total kecuali owner. Penjaga grup di atas tetap jalan.
    if (!isOwner && await isUserBanned(sock, m, sender).catch(() => false)) return

    // grup yang di-banchat: bot tidak merespon siapa pun kecuali owner (supaya bisa .unbanchat).
    // Penjaga grup (antilink dst) di atas tetap jalan.
    if (isGroup && !isOwner && isChatBanned(jid)) return

    const body = m.body || ''
    const { isCmd, prefix, command, text } = parseCommand(body)

    // blacklist global (config.js -> global.fitur.blacklist): nomor / grup / command / kata diabaikan total, owner lolos
    if (await fiturBlacklisted(sock, m, { sender, command: isCmd ? command : '', text, isOwner })) return

    // AFK: user yang AFK kembali kalau mengirim pesan; pengirim yang menandai user AFK diberi tahu
    // (.afk sendiri dilewati supaya tidak langsung membatalkan AFK-nya)
    if (!isTelegram) await afkCheck(sock, m, { skip: isCmd && command === 'afk' })

    const chatType = isGroup ? 'Group' : 'Private'
    const reply = m.reply
    const example = (usage) => sendExample(sock, m, { prefix: isCmd ? prefix : primaryPrefix(), command: ctx.command, usage })

    if (isCmd) await logMessage(true, { sock, m, pushName: m.pushName, number, chatType, jid, prefix, command, text, body, isOwner, isTelegram, isGroup })

    // isPremium diisi ulang di bawah (setelah metadata grup tersedia) khusus untuk command
    const ctx = { sock, text, prefix, command, reply, example, sender, jid, isOwner, isAdmin: false, isPremium: isOwner, body, isCmd }

    if (body && await runDevtools(sock, m, ctx)) return

    if (!isCmd) {
        if (body) await runPassivePlugins(sock, m, ctx)
        return
    }

    let meta = null
    if (isGroup) {
        try {
            meta = await getMeta(sock, jid)
            ctx.isAdmin = isAdminJid(meta, sender, m.key.participantAlt, m.key.participantPn)
        } catch {
            ctx.isAdmin = false
        }
    }
    // owner selalu premium; user lain premium kalau terdaftar lewat .addprem dan belum kedaluwarsa
    ctx.isPremium = isOwner || await isPremiumUser(sock, m, sender, meta).catch(() => false)
    // akun sendiri dianggap admin supaya fitur group tidak menolak; WhatsApp tetap
    // menolak aksi admin sungguhan kalau akunmu bukan admin di grup itu
    if (selfPriv) ctx.isAdmin = true

    // command utama dicari dulu; kalau tidak ada, cari plugin yang punya command itu sebagai sub-command
    // Telegram: plugin kategori rich / rpg / relationship / user / fun / clan tidak direspon sama sekali
    const tgHidden = isTelegram ? telegramHidden() : null
    // mode bot (config.js -> global.botMode / command .botmode): SELAIN owner, hanya kategori
    // yang diizinkan yang terlihat & bisa dipakai. Owner selalu lolos (botMode = null untuknya).
    const botMode = isOwner ? null : botModeOn()
    const visiblePlugins = Object.values(global.plugins).filter(pl => !(tgHidden && isTelegramHidden(pl, tgHidden)))
    const allPlugins = botMode ? visiblePlugins.filter(pl => isBotModeAllowed(pl, botMode)) : visiblePlugins
    // sub-command kini ada di plugin.command; kalau namanya bentrok, plugin yang command UTAMA-nya cocok didahulukan
    const direct = allPlugins.filter(pl => matchPlugin(pl, command))
        .sort((a, b) => (Array.isArray(b.command) && b.command[0] === command) - (Array.isArray(a.command) && a.command[0] === command))
    const candidates = direct.length ? direct : allPlugins.filter(pl => matchSub(pl, command))

    // tidak ada plugin yang cocok: cek command custom grup (.addlistgc), mis. .rules buatan admin
    if (!candidates.length && isGroup) {
        try { if (await runGroupCustom(sock, m, ctx)) return } catch (e) { console.error('[listgc]', e) }
    }

    // command sebenarnya ada tapi diblokir karena botMode (bukan command owner, supaya tidak
    // bocorin command owner tersembunyi ke user biasa) -> kasih tahu daripada diam saja
    if (!candidates.length && botMode) {
        const blocked = visiblePlugins.some(pl => !pl.owner && (matchPlugin(pl, command) || matchSub(pl, command)))
        if (blocked) return reply(`Bot sedang dalam mode *${botMode}*. Command ini sedang nonaktif.`)
    }

    for (const plugin of candidates) {
        // sub-command: `.acakan undi ...` -> plugin acakan menerima command `undi`
        // atau dipanggil langsung: `.undi ...` (command lama)
        const routed = direct.length ? routeSub(plugin, command, text) : { command, text }
        ctx.command = routed.command
        ctx.text = routed.text

        // WAJIB DAFTAR: semua fitur plugin hanya untuk user terdaftar (.daftar). Owner & akun bot lolos.
        // Command bebas daftar diatur di config.js -> global.bebasDaftar (default: daftar, unreg).
        if (wajibDaftarOn() && !ctx.isOwner && !selfPriv && !isRegisterFree(plugin, command, routed.command)) {
            if (!(await isRegisteredUser(sock, m))) return promptRegister(sock, m, ctx, prefix || primaryPrefix() || '.')
        }

        if (plugin.owner && !ctx.isOwner) return reply(global.mess.owner)
        if (plugin.premium && !ctx.isPremium) return reply(global.mess.premium)
        // owner tidak dicek admin (lihat catatan di atas); user biasa wajib admin sungguhan
        if (plugin.admin && !ctx.isAdmin && !ctx.isOwner) return reply(global.mess.admin)
        if (plugin.group && !isGroup) return reply(global.mess.group)
        if (plugin.private && isGroup) return reply(global.mess.private)

        // command TANPA input (mis. ".pin" saja): kalau plugin cuma menampilkan cara pakai, limit TIDAK berkurang.
        // Berlaku untuk semua jenis plugin (kodenya ada di blok LIMIT GATE di atas). Dengan input (".pin kaguya") limit normal.
        let bare = null
        if (!ctx.isPremium && !hasInput(m, ctx)) {
            bare = await beginBare({
                sock, m, ctx, plugin, pluginsDir: PLUGINS_DIR,
                getUser: async () => rpgStore().users?.[await toPN(sock, m.sender)] || null,
                save: () => saveDB(global.db)
            }).catch(() => null)
        }

        // limit dipotong sebelum fitur jalan (notif terpakai + sisa dikirim dulu); refundLimit dipanggil kalau error
        let refundLimit = null
        if (plugin.limit && !ctx.isPremium) {
            refundLimit = await cekLimit(sock, m, Number(plugin.limit) || 1, ctx)
            if (!refundLimit) { bare?.cancel(); return }
        }

        try {
            recordCommand(ctx.command, sender, m.pushName)
            fiturLog(sock, m, { command: ctx.command, text: ctx.text, sender, isOwner: ctx.isOwner }).catch(() => null)
            // konteks pengirim dipakai fitur yang memakai token pribadi (GitHub/Vercel/VPS/panel)
            const runPlugin = () => credCtx.run({ sender, isOwner: ctx.isOwner }, () => plugin(m, ctx))
            await (bare ? bare.run(runPlugin) : runPlugin())
            await bare?.finish()
            // misi harian (.misi): hitung command yang berhasil dijalankan
            // (dilewati di Telegram: misi & badge adalah fitur RPG/user yang disembunyikan di sana)
            if (!isTelegram) {
                trackMisi(sock, sender, ctx.command, plugin).catch(() => null)
                // badge / achievement: hitung command, streak harian, buka badge baru
                trackBadge(sock, m, sender).catch(() => null)
            }
        } catch (e) {
            bare?.cancel()
            refundLimit?.()
            console.error(e)
            await reply(typeof e === 'string' ? e : `🍅 Terjadi error: ${e?.message || String(e)}`).catch(() => null)
        }
        break
    }
}
