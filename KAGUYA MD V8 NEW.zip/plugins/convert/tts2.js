/**
 * Kaguya Multi Device — WhatsApp & Tele Bot
 * Plugin  : Tools — Text to Speech (tts2) 178 model suara
 * Source  : https://starlabs.biz.id
 *
 * Contoh:  .tts2 Hai, nama saya Rohan        → suara default (#100)
 *          .tts2 5 Hello everyone            → pakai suara nomor 5
 *          .tts2list [halaman]               → daftar suara
 *          reply teks + .tts2 8              → baca teks yang di-reply
 */

import axios from 'axios'

const DEFAULT_VOICE = 100
const PER_PAGE = 30
const MAX_CHARS = 1000

// [nama, gender (m/f/n), voice_id] — nomor = urutan + 1
const V = [
    ['Bennett Cole - Natural Chat', 'm', '250173c4-4548-4a66-9eb4-a980c2f601d7'],
    ['Miles - Bright Narrator', 'm', 'e33966e0-949e-4e29-863e-c8cc7cd961ff'],
    ['Derek - Bold Action Voice', 'm', '56b2624d-fea2-4ae2-9410-7d11e3695bdc'],
    ['Asher Lane - Dark Grit', 'm', '87098563-0297-42b1-8ffc-48322073ceda'],
    ['Nadia Wells - Youthful Spark', 'f', '35ca820f-b836-4419-a829-3cfdb714211e'],
    ['Maeve Harper - Expressive Energy', 'f', '95ebe841-7e92-4361-aa87-167b5b3979b1'],
    ['Felix Carter - Expressive Voice', 'm', 'cbe44fd9-c661-496a-8018-c40c013ad55b'],
    ['Anya Reed - Calm Meditation', 'f', 'fcb2c362-4789-4938-94f6-c68f2ddd73dc'],
    ['Finn - Mischievous Character', 'm', '3c9f2d9f-048e-4fed-9590-9b61f14d4a14'],
    ['Graham - Gentle Studio Man', 'm', '90ed1a4e-fe7f-493e-965c-dc06e02760a8'],
    ['Pip - Playful Character', 'n', '6ec5b6ac-30ff-4c6d-be95-c1be76ff7c08'],
    ['Dylan Marlow - Gentle Trust', 'm', '449fa787-480c-4857-b249-d2640c7fc332'],
    ['Gemma Cole - Engaging Educator', 'f', 'cbfef6aa-aeb9-4219-a6a1-2e7fedc6ec57'],
    ['Mason Clarke - Warm Storyteller', 'm', '13e7914d-ab0e-4149-bc05-69a41895ebfa'],
    ['Lydia Stone - Professional Guide', 'f', 'ccbc80fc-39c0-406b-823e-5206c1db5bdc'],
    ['Isla Rowan - Audiobook Pro', 'f', '804c1671-40a5-4709-ae1b-e865923f9de4'],
    ['Maren - Serene Narration', 'f', '14b0a424-93aa-4b72-b5e7-33cccaeec09a'],
    ['Sienna Ford - Neutral Guide', 'f', '2d8ff908-3438-4ede-ab0c-bac36bb06dcf'],
    ['Julian Cross - Relaxed Optimist', 'm', 'db21c21d-3db0-4803-bade-4f84b06472be'],
    ['Elara Wynn - Warm Reflection', 'f', 'c97ef63a-2488-49f6-92d4-a0f60ddd9b7e'],
    ['Tobias Wynn - Laid Back Resonance', 'm', '00a01440-b3f2-4c7f-b919-53d9a79dc482'],
    ['Hugo Porter - Resonant Comfort', 'm', '5ff07236-d221-4127-b5b9-bb4f597309c7'],
    ['Fiona Ash - Quirky Energy', 'f', '6549443e-1de2-45d7-85ea-2d7ee3f9dff1'],
    ['Logan Frost - Broadcast Anchor', 'm', 'd88039cd-4bde-4c85-b262-8750a5dff06d'],
    ['Elise - Charming Studio Voice', 'f', '2e27b183-1700-4aab-8619-c3a3a7db3c28'],
    ['Clara Vale - Pro Voice', 'f', 'a3b46b70-fb74-4e7b-8a3d-2b02eb5e2089'],
    ['Graham Pierce - Fierce Warrior', 'm', 'ced9b140-58e2-4e4f-ae9f-7a8a693e3e7c'],
    ['Clara Bell - Holiday Host', 'n', 'af503ab1-c1d8-43dc-9fbb-0448d0153f2c'],
    ['Vera Sloan - Bright Friendly', 'f', 'b9b9c236-4a7e-4d5b-8073-a866d3f2cb11'],
    ['Selene Ward - Mysterious Mood', 'f', '61dd7853-ebb7-44e9-81ad-782e4adb541e'],
    ['Elliot Nash - Energetic Clarity', 'm', '93894c8b-70c0-4274-b4ff-f3b2e1f07503'],
    ['Wesley Ford - Firm Authority', 'm', 'fea9dc07-d584-4a11-b3ec-926bcc0999df'],
    ['Miles Archer - Social Spark', 'm', 'a6747141-36bf-454f-9594-1ec58ab4b168'],
    ['Mara Ellis - Clear Upbeat', 'f', '054c7d26-3d98-4669-9e26-e31badadbea7'],
    ['Tessa Hart - Grounded Pro', 'f', 'b7c52df0-7271-47ef-880a-036d78ee662d'],
    ['Olive Pierce - Social Bright', 'f', '8f0d66fc-aa3d-432a-b242-a96e1ea26cfa'],
    ['Reid Sutton - Bold Husky', 'm', '72a01b7f-d69d-45f8-b940-029ff6b3a23e'],
    ['Nora - Holiday Storyteller', 'm', '0f727e72-07b2-47ce-b030-caec6d06588c'],
    ['Holden Gray - Deep Energy', 'm', 'f969ef25-8c40-4a4d-b60b-55daa0048632'],
    ['Cora Blake - Reassuring Voice', 'f', '937fc4de-f958-4edf-9af7-e1efcc5c5c44'],
    ['Daphne Brooks - Eloquent Villain', 'f', '039d2648-ce4f-441a-af43-2a816e8e27a8'],
    ['Calvin - Diligent Tutor', 'm', 'c151308e-0c3a-4594-86eb-9ee5a61c8be0'],
    ['Nova Quill - Squeaky Cartoon', 'n', 'e43e6aaa-f3f8-4665-937f-70aed9d585ee'],
    ['Ronan Blake - Husky Trickster', 'm', '7d8d0141-12ce-4e36-ab98-e176eccf2fd7'],
    ['Noel - Gentle Voice', 'm', 'b67eeddb-050e-430e-ac6a-f830eeb4affa'],
    ['Dorian Hale - Smooth Trust', 'm', 'f2c20379-2cdb-4fc4-8e2d-b45656d992c3'],
    ['Sawyer Quinn - Smooth Depth', 'm', '115fa464-f0ca-476d-90e9-79739a0c6557'],
    ['Silas Reed - Inspiring Clarity', 'm', '098bc3b1-1d24-49b5-943a-5c4b21290acf'],
    ['Maisy - Sweet Young Voice', 'f', '66d50678-80d2-48a3-9e6a-b5ae019cd09c'],
    ['Iris Camden - Warm Clear Voice', 'f', '6a16ef5c-0dd4-4f4d-a875-35afa6404146'],
    ['Evelyn Rose - Graceful Narration', 'f', '67775b37-9bd4-4023-afa4-499b479687b6'],
    ['Parker Hayes - Balanced Wisdom', 'm', '973a341d-f0b9-4ed4-9f0b-e0c45a329bd0'],
    ['Orion Vale - Deep Shadow', 'n', 'b9d11507-5fc4-4474-99f5-243b4d39734b'],
    ['Celia North - Bright Warmth', 'f', '55336d23-b294-4d7d-83b5-c2f446a9c81a'],
    ['Owen Hart - Wise Host', 'm', 'cc0f9a7c-c385-47e5-919f-7050e88d3f34'],
    ['Phoebe Lane - Bright Professional', 'f', 'd7d4da58-c6e8-4169-8c7a-f4ed44286968'],
    ['Theo Grant - Studio Voice', 'm', '3311f051-e70d-44c1-a53f-37b7e119e80d'],
    ['Opal Finch - Velvet Actress', 'f', 'e482d7c9-15c6-4980-8b11-e7d7af7e8185'],
    ['Skye - Bright Young Voice', 'f', '22531df0-6e68-43d8-b8f2-61cc311d3acc'],
    ['Hugh - Relaxed Aussie Voice', 'm', '0028607d-3914-4393-a0f2-e1ab21d05371'],
    ['Evan Mercer - Casual Light', 'm', 'f6a29718-f486-447d-9485-c90c2ca5b498'],
    ['Grant - Trustworthy Guide', 'm', 'b615d4a2-6aed-4d0f-b77d-3c585853ed65'],
    ['Mira Caldwell - Crisp Voice', 'f', '18238c9f-fc4e-49e3-9aab-b168f15053d7'],
    ['Caleb Stone - Grounded Charm', 'm', 'd3e63990-1fea-4916-83a8-d75b78b705bb'],
    ['Nolan Brooks - Grounded Storyteller', 'm', '2881b1e1-9322-4e1b-9d9d-e10ec67f0569'],
    ['Aiden Brooks - Confident Voice', 'm', 'dbba07d8-de99-41dd-ad99-134c7d5c7c2e'],
    ['Nora Vale - Upbeat Voice', 'f', '38b7c7f8-112b-40bd-b7e2-05afb2125b54'],
    ['Ethan Cross - Calm Guide', 'm', 'f713280c-0b22-4765-a92c-d040700d5e03'],
    ['Maya Sterling - Deep Narrator', 'm', '2a59cad2-ce23-47ce-82e5-8bc7af411f4a'],
    ['Lucas Grey - Natural Voice', 'm', 'ca683601-6fba-4b05-9d06-96493322c108'],
    ['Ivy Monroe - Deep Narrator', 'm', 'a8b06589-c5d2-4003-b58e-d16e3a68afed'],
    ['Grant Ellis - Studio Professional', 'm', 'c63c4362-1cbc-4e0e-a30a-23e40238d9a5'],
    ['Clara Sutton - Character Signal', 'm', 'f997764f-7eb6-455c-b4be-9ce0cce4e2a8'],
    ['Rowan Pierce - Calm Guide', 'm', '8e3c8b23-c86d-4846-b1e2-714d0fc12b98'],
    ['Elena Hart - Calm Guide', 'm', '506cd3e7-a231-41dc-9b5c-25bdcd96f105'],
    ['Miles Donovan - Deep Narrator', 'm', '39ab9b24-43fd-4d5c-a1af-3b1ddec1ae51'],
    ['Audrey Lane - Natural Voice', 'm', 'f0acf423-fa97-457a-819e-9e5ebe40ab18'],
    ['Caleb Reed - Natural Voice', 'm', '266d895c-56ca-4633-a8f6-7b77f8b3d596'],
    ['Sophie Arden - Dramatic Edge', 'm', 'fc0d7b0b-e5e4-490e-97e3-f2b380d5c6ed'],
    ['Noah Bennett - Calm Guide', 'm', 'ee5ac19f-431d-491a-abfe-c104d92cf4d7'],
    ['Lila Morgan - Natural Voice', 'm', '33b57e16-f0b9-47ef-84d3-6d8cd57aae62'],
    ['Jasper Cole - Deep Narrator', 'm', 'd6df79e3-c030-44bd-bb21-4d2c1b49eea8'],
    ['Ava Sinclair - Confident Voice', 'm', '43912274-ac58-417e-982a-b5dacd4e900d'],
    ['Theo Mason - Deep Narrator', 'm', '3a17fc53-1c2e-4d05-852f-078c44e276f3'],
    ['Grace Hollis - Deep Narrator', 'm', '4bcd3a36-b33e-454f-aa65-3efd480258da'],
    ['Elliot Hayes - Calm Guide', 'm', '5bdf0e5c-1e36-41d0-a081-f0dd06cdf95c'],
    ['Mara Quinn - Studio Professional', 'm', '74b57fbb-f353-4ebb-9ae7-b12f31c4280a'],
    ['Owen Blake - Confident Voice', 'm', '84508b35-81c6-42bb-a003-95e23c96944f'],
    ['Chloe Rowan - Mature Narrator', 'm', 'eef86dd3-2c10-4e50-82e4-10e0ac82248c'],
    ['Felix Shaw - Natural Voice', 'm', 'f67aa759-ef92-4dcb-b79a-d9e2a37d2226'],
    ['Isabel Stone - Mature Narrator', 'm', '9cd48997-8f66-4d9a-a4c9-05549b4e4c86'],
    ['Graham Wilde - Confident Voice', 'm', 'c72187cf-cb90-44fa-b5bc-d80ea075fb4a'],
    ['Luna Mercer - Calm Guide', 'm', 'c0b4503c-e877-4b44-bcc0-66923958181d'],
    ['Reid Parker - Calm Guide', 'm', '4cd78ca5-5fd9-4d7d-908f-5095470f5a02'],
    ['Amelia Ross - Mature Narrator', 'm', 'eb52a9fe-8eb1-4f80-b84e-a4767b46a2ac'],
    ['Silas Ford - Upbeat Voice', 'm', '67bb182d-9e24-4fd4-9ddc-d94dddb906e7'],
    ['Violet James - Natural Voice', 'm', '6431d65c-7a47-400f-9d0b-15eb35731965'],
    ['Bennett Sloan - Natural Voice', 'm', '665dac31-8f7d-427c-b71e-7fcacb3848a6'],
    ['Celia Wynn - Deep Narrator', 'm', 'efb97153-f275-4962-aeeb-c3ea59f991be'],
    ['Dorian Chase - Natural Chat', 'f', 'fd7d3e2d-4c59-4b00-9bc8-42c463dc9bf2'],
    ['Phoebe Grant - Warm Clarity', 'f', '6be28b0e-7e4f-47a9-9398-ade054995bc6'],
    ['Logan Vale - Clear Presenter', 'f', 'c2aaefc8-fd52-4e2b-9228-ee257f5ee1e5'],
    ['Elise Carter - Confident Voice', 'f', 'f6532c88-f2ec-46a5-b1e1-ce55713cf2cd'],
    ['Wesley North - Confident Voice', 'm', '80bb0145-667f-4610-bd20-cfdb1a146af6'],
    ['Iris Bell - Upbeat Voice', 'm', '0c791d50-bb29-4922-9584-d78461cf602b'],
    ['Archer Flynn - Natural Voice', 'f', '7a5b3bb9-255b-4256-bc7f-cb36aa9c3863'],
    ['Tessa Reed - Calm Guide', 'f', 'e57dd905-00ab-43dd-baa0-0116142ecd5a'],
    ['Julian Hart - Natural Chat', 'm', '2df3bf3d-7068-4253-b11d-7e71aea4c9c8'],
    ['Nadia Cole - Calm Guide', 'f', '39cbde87-28d3-4182-836a-c8f50d4dae54'],
    ['Mason Brooks - Studio Professional', 'm', '53db300d-1448-4fe6-ac35-a8dcf3d5ca34'],
    ['Skye Harper - Natural Chat', 'f', 'b439cdce-b561-477d-bc52-74353c5a4f4c'],
    ['Ronan Pierce - Warm Clarity', 'm', 'fb3ac619-c9cb-4a81-80f8-493b5334c1f5'],
    ['Olive Clarke - Natural Chat', 'm', '08839697-a0e4-4861-8ffa-591f43a8f6b3'],
    ['Holden Nash - Deep Narrator', 'm', '915ccee1-0178-44eb-8353-5b8f418dcef2'],
    ['Sienna Ward - Bright Character', 'f', '3dd2f565-395b-42c8-a6b8-774ea08bc391'],
    ['Adrian Ashford - Raspy Podcast Host', 'm', 'caec1301-501a-4b8d-aaea-48dcad14f2a4'],
    ['Abigail Ashford - Grounded Community Host', 'f', 'a711e120-d33d-460c-8395-6f57255f6b08'],
    ['Arthur Ashford - Crisp Reflective Storyteller', 'm', 'f68c788c-0f7d-4e54-a8cf-55d5eedf80b1'],
    ['Cedric Ashford - Velvety Storyteller', 'm', '004b66a0-2545-4643-ae59-c73889c22f51'],
    ['Cecilia Ashford - Sprightly Animated Sidekick', 'f', '860bb4d7-92aa-430d-a9b1-2312517d4ba6'],
    ['Colin Ashford - Weathered Philosopher', 'm', '61faa813-d9bc-4f1e-84de-db3a6ba275a3'],
    ['Diana Ashford - Velvety Community Storyteller', 'f', '1b4a39df-d0ba-469a-bae3-6507aef17482'],
    ['Dominic Ashford - Velvety Sleep Narrator', 'm', 'f1cd6c3c-b7c9-45c0-b845-9b7a70052c77'],
    ['Estelle Ashford - Breathy Whimsical Storyteller', 'f', 'f491b82f-3b57-4f51-b0b6-b499960ffd14'],
    ['Edmund Ashford - Textured Tech Instructor', 'm', '796fcaf5-a106-474f-8e95-1f6638991d26'],
    ['Felicity Ashford - Husky Reflective Storyteller', 'f', '74f7ce37-b924-4e12-b74e-49efc03d7ea0'],
    ['Gavin Ashford - Husky Southern Storyteller', 'm', '9a8ada06-1460-4beb-bd63-9fb62238a09c'],
    ['Georgia Ashford - Deep Southern Storyteller', 'f', '234d7374-3baf-4385-aefd-429b8059e972'],
    ['Hector Ashford - Gravelly Fantasy Storyteller', 'm', '09a27c41-d5d1-4db5-ad06-78e11b231117'],
    ['Helena Ashford - Bright Digital Explainer', 'f', '29873965-1944-458c-8b6a-6f8bf65f3d24'],
    ['Imogen Ashford - Gravelly Storyteller', 'f', '4d930efd-e5d3-4ce4-b7b3-eb4c09da33a0'],
    ['Josephine Ashford - Brisk Friendly Announcer', 'f', '3a4e2350-cc5a-413e-b1cc-fff0446d5e5b'],
    ['Katherine Ashford - Whimsical Tale Storyteller', 'f', 'f586b423-91ce-4fce-81e0-91d7a07d1496'],
    ['Patrick Ashford - Lively Storybook Tenor', 'm', 'e9a50df4-940d-424a-8c15-763644500e83'],
    ['Marina Ashford - Husky Mindfulness Guide', 'f', 'ef2181f2-b701-4a13-bd02-d9891751768a'],
    ['Quentin Ashford - Gravelly Character Performer', 'm', '83846ea9-1027-41bf-ab1f-cfbe81c40faf'],
    ['Natalie Ashford - Warm Civic Anchor', 'f', '5b46f04c-0992-4cac-b688-cac3fe6d6370'],
    ['Rupert Ashford - Hushed Bass Storyteller', 'm', '6f875d95-5c0a-428d-adc0-044d03ad867a'],
    ['Victor Ashford - Bright Textured Explainer', 'm', '2955b92b-d002-4b41-b65c-a32905bbc2f5'],
    ['Sylvia Ashford - Husky Reflective Host', 'f', '551eca4b-e090-4a7c-b9f5-8241fbae8da2'],
    ['Vincent Ashford - Gravelly Storyteller', 'm', '7816f578-46bc-48b7-87fc-6f666fef301d'],
    ['Theresa Ashford - Velvety Bedtime Storyteller', 'f', 'f28090f4-226c-4b87-82d9-d925dd08ff5d'],
    ['Vivian Ashford - Bright Fairytale Teller', 'f', '58295afe-1982-4af8-b39b-868791575c85'],
    ['Adrian Bancroft - Warm Workplace Mentor', 'm', '0b859756-4c9d-4458-87ad-654085cbcc4a'],
    ['Arthur Bancroft - Eccentric Storybook Character', 'm', 'b7043bcd-1102-489f-a1d6-a4f51ad1dcd1'],
    ['Beatrice Bancroft - Breathy Gentle Guide', 'f', 'e194dc80-6da5-4381-a5be-71fc88dbad9e'],
    ['Cedric Bancroft - Velvet Bass Storyteller', 'm', '9ceef65f-2f7b-40cb-aa16-8444866f75a7'],
    ['Diana Bancroft - Gentle Bedtime Storyteller', 'f', '5186f14c-151f-4559-9ed4-7c514a4a928b'],
    ['Dominic Bancroft - Gravelly Animated Mentor', 'm', 'a4b55d91-3b6f-4543-8fe5-36770901b4aa'],
    ['Estelle Bancroft - Breathy Mindfulness Guide', 'f', '761557b1-7da7-45b1-8af6-acf5b3e98505'],
    ['Edmund Bancroft - Husky Community Host', 'm', '5942e484-88af-4f6b-bea7-faeadde770a8'],
    ['Georgia Bancroft - Velvety Meditative Host', 'f', '07b2ca75-a404-48eb-a03c-696f6f98bc8c'],
    ['Hector Bancroft - Textured Theatrical Storyteller', 'm', 'd5d85b59-fe84-4746-b352-7464a3625897'],
    ['Imogen Bancroft - Husky Executive Coach', 'f', '1c7cb1a8-7dbf-428e-ac70-a87764941861'],
    ['Josephine Bancroft - Buoyant Wellness Host', 'f', '023bec35-cb7e-4fac-af1b-e097a22860fa'],
    ['Katherine Bancroft - Soft Mindful Storyteller', 'f', '3deeb9ef-a4e8-42ca-8e80-6c57f05d8579'],
    ['Oscar Bancroft - Crisp Mystery Narrator', 'm', '01b9d81a-8a91-40f6-8840-31df5262a017'],
    ['Patrick Bancroft - Zippy Explainer Host', 'm', '3ff15f48-3587-425b-aaac-a3e83387c9f6'],
    ['Natalie Bancroft - Velvety Meditation Guide', 'f', '7b1e16f0-7d86-448d-8e5f-c884299c21c6'],
    ['Rupert Bancroft - Bright Radio Broadcaster', 'm', '0a40e9a5-e887-49d5-ac43-b41d08acb172'],
    ['Tristan Bancroft - Soft Meditative Guide', 'm', '69f58d15-b0e2-476e-98f9-30201825ea0a'],
    ['Victor Bancroft - Bright Animated Storyteller', 'm', '0bf14ef5-429c-4710-8256-f610bcb1203e'],
    ['Sylvia Bancroft - Warm Direct Advisor', 'f', '02e0637e-c3cb-46dd-8eff-b1312cb53db6'],
    ['Theresa Bancroft - Bright Lifestyle Host', 'f', '835521d8-594b-4d91-8df2-e09c7956b8f5'],
    ['Walter Bancroft - Reedy Civic Broadcaster', 'm', 'e9a5f141-990e-4603-b0e9-d7a5cef03be5'],
    ['Xavier Bancroft - Craggy Gentle Storyteller', 'm', '10a021c8-65c1-495b-9a9e-c1e3ac3d7ad0'],
    ['Willa Bancroft - Smoky Mystery Narrator', 'f', 'face2abf-7363-482c-94e8-7c20276f454e'],
    ['Adrian Callahan - Whimsical Elder Mentor', 'm', '0a36c038-7564-4054-ae92-1252055f1fbc'],
    ['Abigail Callahan - Serene Bedtime Narrator', 'f', '4a0e6ce5-3a5b-468d-b0df-303eb79a9d2c'],
    ['Arthur Callahan - Bright Animated Character', 'm', 'e06d643e-912b-4182-b2f8-09960ab336fa'],
    ['Cedric Callahan - Velvety Sleep Guide', 'm', '6522616f-8da9-4a28-8c34-6cdf674d7bdc'],
    ['Colin Callahan - Gravelly Chronicler', 'm', 'b16d60e9-cc13-42ab-8f9c-79c11a576771'],
    ['Dominic Callahan - Bright Upbeat Explainer', 'm', '3ac8a645-c407-4bb7-abee-bca369bbd8d2'],
    ['Edmund Callahan - Raspy Fantasy Villain', 'm', 'bcf2d6e6-7a75-4875-ad0e-d2c5e5d9f43a'],
    ['Felicity Callahan - Hushed Storyteller', 'f', '5435fa3e-5aa9-4330-a57e-b090b4d66538'],
    ['Georgia Callahan - Husky Reflective Storyteller', 'f', 'b241d684-3426-498f-8fab-f7cd0aa6b420'],
    ['Hector Callahan - Theatrical Raspy Storyteller', 'm', 'f9fc053b-674c-419e-b2ce-7f15ddb682ec'],
    ['Helena Callahan - Smoky Deliberate Mentor', 'f', 'd7a1328c-16ba-49d4-8885-4bd00dabdc46']
]

const GENDER = { m: '♂', f: '♀', n: '⚧' }

let handler = async (m, { sock, text, command, prefix, reply }) => {
    const p = prefix || '.'
    const cmd = (command || '').toLowerCase()

    // ── daftar suara ──
    if (cmd === 'tts2list' || cmd === 'listtts2') {
        const totalPage = Math.ceil(V.length / PER_PAGE)
        const page = Math.min(Math.max(parseInt(text) || 1, 1), totalPage)
        const start = (page - 1) * PER_PAGE
        const rows = V.slice(start, start + PER_PAGE)
            .map(([nama, g], i) => `${start + i + 1}. ${GENDER[g]} ${nama}`)
            .join('\n')
        return reply(
            `🎙️ *DAFTAR SUARA TTS2* (${V.length} suara)\n` +
            `Halaman ${page}/${totalPage}\n\n${rows}\n\n` +
            `💡 Pakai: ${p}tts2 <nomor> <teks>\n` +
            (page < totalPage ? `➡️ Halaman berikut: ${p}tts2list ${page + 1}` : '')
        )
    }

    // ── parse: [nomor] teks ──
    let input = (text || '').trim()
    let nomor = DEFAULT_VOICE
    const mt = input.match(/^(\d{1,3})\s+([\s\S]+)$/)
    if (mt && Number(mt[1]) >= 1 && Number(mt[1]) <= V.length) {
        nomor = Number(mt[1])
        input = mt[2].trim()
    } else if (/^\d{1,3}$/.test(input) && m.quoted) {
        // ".tts2 8" + reply teks
        nomor = Number(input)
        input = ''
    }
    if (!input) input = (m.quoted?.text || m.quoted?.caption || '').trim()

    if (!input) {
        return reply(
            `🎙️ *TEXT TO SPEECH*\n\n` +
            `${p}tts2 <teks> → suara default (#${DEFAULT_VOICE})\n` +
            `${p}tts2 <nomor> <teks> → pilih suara\n` +
            `${p}tts2list → lihat ${V.length} suara\n\n` +
            `*ᴄᴏɴᴛᴏʜ:* ${p}tts2 5 Hello everyone`
        )
    }
    if (!V[nomor - 1]) return reply(`❌ Voice nomor ${nomor} tidak ditemukan! Cek ${p}tts2list`)
    if (input.length > MAX_CHARS) return reply(`❌ Teks terlalu panjang (maks ${MAX_CHARS} karakter).`)

    const [nama, , voiceId] = V[nomor - 1]

    try {
        const { data } = await axios.post(
            'https://starlabs.biz.id/startts/proxy.php',
            new URLSearchParams({
                action: 'generate',
                text: input,
                voice: voiceId,
                stream: '1',
                b64: '1'
            }).toString(),
            {
                responseType: 'arraybuffer',
                headers: {
                    Accept: '*/*',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    Origin: 'https://starlabs.biz.id',
                    Referer: 'https://starlabs.biz.id/startts/id',
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36'
                },
                timeout: 60000
            }
        )

        const audio = Buffer.from(data)
        if (!audio.length) throw new Error('Respon audio kosong')

        await sock.sendMessage(
            m.chat,
            { audio, mimetype: 'audio/mpeg', ptt: false },
            { quoted: m }
        )
    } catch (e) {
        const detail = e.response?.data
            ? Buffer.from(e.response.data).toString().slice(0, 300)
            : e.message
        return reply(`❌ Gagal membuat suara (${nama}):\n${detail}`)
    }
}

handler.command = ['tts2', 'tts2list', 'listtts2']
handler.help = ['tts2 [nomor] <teks>', 'tts2list [halaman]']
handler.tags = ['tools']
handler.limit = true

export default handler
