/**

* Kaguya Multi Device — WhatsApp & Tele Bot
* 
* Library      : whiskeysockets baileys
* Type         : Plugins | ESM Modules
* Creator      : YannRzy Tech
* Recode       : (Your Name)
* 
* Developer Channels:
* • https://whatsapp.com/channel/0029VaoMGuLA89MbfGh62V16
*
* Info Update Kaguya Channels:
* • https://whatsapp.com/channel/0029VabymHd4CrfnqPLPzk3n
* 
* Copyright © YannRzy Tech 2026
* All Rights Reserved.
  */
import { execSync } from 'node:child_process'
import { existsSync } from 'node:fs'

let puppeteerLib = null
async function loadPuppeteer() {
    if (puppeteerLib) return puppeteerLib
    try {
        const [{ default: extra }, { default: Stealth }] = await Promise.all([
            import('puppeteer-extra'),
            import('puppeteer-extra-plugin-stealth')
        ])
        extra.use(Stealth())
        puppeteerLib = extra
    } catch {
        const { default: plain } = await import('puppeteer')
        puppeteerLib = plain
    }
    return puppeteerLib
}

function getChromiumPath(pp) {
    const termuxPath = '/data/data/com.termux/files/usr/bin/chromium'
    if (existsSync(termuxPath)) return termuxPath

    try {
        const found = execSync('which chromium || which chromium-browser || which google-chrome', {
            stdio: ['pipe', 'pipe', 'ignore']
        }).toString().trim()
        if (found) return found
    } catch (_) {}

    // fallback: chromium bawaan puppeteer (kalau terunduh)
    try {
        const p = pp?.executablePath?.()
        if (p && existsSync(p)) return p
    } catch (_) {}

    return null
}

export async function dolaChat(prompt, options = {}) {
    const {
        proxy = null,
        headless = 'new',
        timeout = 35000,
        streamTimeout = 45000,
        blockResources = true,
        executablePath = null
    } = options

    if (!prompt || typeof prompt !== 'string' || !prompt.trim()) {
        return { status: false, prompt: prompt || '', error: 'Prompt pertanyaan tidak boleh kosong.' }
    }

    const puppeteer = await loadPuppeteer()
    const autoExecutablePath = executablePath || getChromiumPath(puppeteer)
    if (!autoExecutablePath) {
        return { status: false, prompt: prompt.trim(), error: 'Chromium tidak ditemukan! Silakan install Chromium terlebih dahulu.' }
    }

    let browser = null
    try {
        const launchArgs = [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-blink-features=AutomationControlled',
            '--no-first-run',
            '--no-default-browser-check'
        ]

        if (blockResources) launchArgs.push('--blink-settings=imagesEnabled=false')

        let proxyAuth = null
        if (proxy) {
            let proxyServer = ''
            if (typeof proxy === 'string') {
                try {
                    const parsed = new URL(proxy.includes('://') ? proxy : `http://${proxy}`)
                    proxyServer = `${parsed.protocol}//${parsed.hostname}${parsed.port ? `:${parsed.port}` : ''}`
                    if (parsed.username || parsed.password) {
                        proxyAuth = { username: decodeURIComponent(parsed.username), password: decodeURIComponent(parsed.password) }
                    }
                } catch {
                    proxyServer = proxy
                }
            } else if (typeof proxy === 'object') {
                proxyServer = proxy.server
                if (proxy.username || proxy.password) {
                    proxyAuth = { username: proxy.username, password: proxy.password }
                }
            }
            if (proxyServer) launchArgs.push(`--proxy-server=${proxyServer}`)
        }

        browser = await puppeteer.launch({
            headless,
            executablePath: autoExecutablePath,
            args: launchArgs
        })

        const page = await browser.newPage()
        await page.setViewport({ width: 1280, height: 800 })

        if (proxyAuth) await page.authenticate(proxyAuth)

        await page.goto('https://www.dola.com/chat/', { waitUntil: 'domcontentloaded', timeout })

        if (page.url().includes('/security/region-restricted')) {
            throw new Error('Akses diblokir oleh dola.com karena pembatasan wilayah (/security/region-restricted).')
        }

        try {
            await page.evaluate(() => {
                const btns = Array.from(document.querySelectorAll('button'))
                const okBtn = btns.find((b) => b.innerText?.trim() === 'OK')
                if (okBtn) okBtn.click()
            })
        } catch (_) {}

        const inputSelector = '.ProseMirror, div[contenteditable="true"], textarea'
        await page.waitForSelector(inputSelector, { timeout: 20000 })
        await new Promise((r) => setTimeout(r, 1000))
        await page.click(inputSelector)

        await page.evaluate((selector) => {
            const el = document.querySelector(selector)
            if (el) el.focus()
        }, inputSelector)

        await page.keyboard.type(prompt.trim(), { delay: 10 })
        await new Promise((r) => setTimeout(r, 400))

        const submitted = await page.evaluate(() => {
            const btns = Array.from(document.querySelectorAll('button'))
            const sendBtn = btns.find((b) =>
                b.className.includes('send-msg') ||
                b.className.includes('send') ||
                b.getAttribute('aria-label')?.toLowerCase()?.includes('send')
            )
            if (sendBtn && !sendBtn.disabled && !sendBtn.className.includes('disabled')) {
                sendBtn.click()
                return true
            }
            return false
        })

        if (!submitted) await page.keyboard.press('Enter')

        for (let i = 0; i < 4; i++) {
            await new Promise((r) => setTimeout(r, 800))
            let confirmed = false
            try {
                confirmed = await page.evaluate(() => {
                    const btns = Array.from(document.querySelectorAll('button'))
                    const confirmBtn = btns.find((b) => b.innerText?.trim() === 'Confirm')
                    if (confirmBtn) {
                        confirmBtn.click()
                        return true
                    }
                    return false
                })
            } catch (_) {}
            if (confirmed) break
        }

        let lastText = ''
        let stableCount = 0
        const startTime = Date.now()

        while (Date.now() - startTime < streamTimeout) {
            await new Promise((r) => setTimeout(r, 1200))
            let extracted = ''

            try {
                extracted = await page.evaluate(() => {
                    const botContainers = Array.from(document.querySelectorAll('[class*="grid-cols-[minmax"]'))
                    if (botContainers.length > 0) {
                        const latest = botContainers[botContainers.length - 1]
                        const answerBlock = latest.querySelector('[data-plugin-identifier*="10000"]')
                        if (answerBlock && answerBlock.innerText?.trim()) return answerBlock.innerText.trim()

                        const clone = latest.cloneNode(true)
                        clone.querySelectorAll('button, svg, [role="toolbar"], [data-plugin-identifier*="search_query"]').forEach((el) => el.remove())
                        let clean = clone.innerText?.trim() || ''
                        return clean.replace(/^(Searching the web\.\.\.|Searched for [^\n]+\n?)/i, '').trim()
                    }

                    const markdownEls = Array.from(document.querySelectorAll('[class*="markdown"], [class*="prose"]'))
                    if (markdownEls.length > 0) return markdownEls[markdownEls.length - 1].innerText?.trim() || ''
                    return ''
                })
            } catch (e) {
                if (e.message?.includes('Execution context was destroyed') || e.message?.includes('Cannot find context') || e.message?.includes('Target closed')) {
                    continue
                }
                throw e
            }

            if (extracted && extracted.length > 0) {
                if (extracted === lastText) {
                    stableCount++
                    if (stableCount >= 2) break
                } else {
                    stableCount = 0
                    lastText = extracted
                }
            }
        }

        if (!lastText) throw new Error('Gagal mendapatkan balasan dari Dola AI.')

        return { status: true, prompt: prompt.trim(), result: lastText }
    } catch (error) {
        return { status: false, prompt: prompt ? prompt.trim() : '', error: error.message || String(error) }
    } finally {
        if (browser) {
            try { await browser.close() } catch (_) {}
        }
    }
}

// satu browser per waktu supaya RAM server tidak jebol
let busy = false

let handler = async (m, { text, prefix, command, reply }) => {
    const query = String(text || m.quoted?.text || '').trim()
    if (!query) return reply(`*Contoh:*\n${prefix || '.'}${command} rekomendasi film sci-fi terbaik`)
    if (busy) return reply('⏳ Dola AI sedang memproses permintaan lain, coba lagi sebentar.')

    busy = true
    try {
        await m.react?.('⏳')
        const res = await dolaChat(query)
        if (!res.status) throw new Error(res.error)
        await m.react?.('✅')
        return reply(res.result)
    } catch (e) {
        console.error('[DOLA]', e)
        await m.react?.('❌')
        return reply(`❌ Gagal: ${e?.message || e}`)
    } finally {
        busy = false
    }
}

handler.command = ['dola', 'dolaai']
handler.help = ['dola <pertanyaan>']
handler.tags = ['ai']
handler.limit = true

export default handler
